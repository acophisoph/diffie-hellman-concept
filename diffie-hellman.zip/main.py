import random
from math import gcd as bltin_gcd

def primRoots(modulo):
    required_set = {num for num in range(1, modulo) if bltin_gcd(num, modulo) }
    return [g for g in range(1, modulo) if required_set == {pow(g, powers, modulo)
            for powers in range(1, modulo)}]


##### min = smallest number to draw random prime from 
##### max = largest number to draw random prime from
min = 10
max = 100
#prime generating function
def primes(x,y):
    prime_list = []
    for n in range(x, y):
        isPrime = True

        for num in range(2, n):
            if n % num == 0:
                isPrime = False

        if isPrime:
            prime_list.append(n)
            
    return prime_list
prime_list = primes(min,max)


# PUBLIC
# p is large public prime
# chose (p-1)/2 also prime
p1_list = []
for n1 in prime_list:
  isPrime = True

  check = int((n1-1)/2)
  for num in range(2, check):
    if check % num == 0:
      isPrime = False

  if isPrime:
    p1_list.append(n1)
p = random.choice(p1_list)
print("public key p =", p)

# g is public prime
# g is primitive root modulo p
# every integer relatively prime to p
# congruent to a power of g mod n (equivalence)
p2_list = []
primroot_list = primRoots(p)
for n2 in primroot_list:
  if n2 > (min-1)/2:
    p2_list.append(n2)
g = random.choice(p2_list)
print("public key g =", g)


#PRIVATE
# a is large number private key Alice
a = random.randint(min, max)
# b is large number private key Bob
b = random.randint(min, max)


#Share Keys
# A = g^a (mod p)
A = g**a % p
print("share key A =", A)
# B = g^b (mod p)
B = g**b % p
print("share key B =", B)


#Public Key
# K = A^b (mod p)
# K = B^a (mod p)
K1 = A**b % p
K2 = B**a % p
K3 = K1 = K2


##### message to send
message = "hello!"
##### standard hash exponent
e = 10
receive_list = []
message_encoded = message.encode(encoding = 'UTF-8')
for bytes in message_encoded:
  #encrypt
  bytes = bytes**e % K3
  #decrypt
  bytes = 
  receive_list.append(bytes)
receive_message = bytearray(receive_list) 
message_decode = receive_message.decode()
print(message_decode)

'''
#Hacking Test
# know g, p, A, B. crack K using only those infos
# g^a^b (mod p) = K
# don't know a or b or K1 = K2 so essentially g^a^b = g^n
##### counter is up to how many powers want to guess
counter = 1000
successes = 0
for number in range(1, counter):
    K = g**number % p
    if K == K3:
      print("hack successful!")
      successes += 1
    else:
      print("hack unsuccessful!")
print("successful hacks percentage =", successes,"/", counter)
'''




'''
Documentation
https://mathworld.wolfram.com/Diffie-HellmanProtocol.html
https://stackoverflow.com/questions/40190849/efficient-finding-primitive-roots-modulo-n-using-python
'''